package main
import (
	"fmt"
	"Uactor/ua"
	"time"
	"log"
	"strconv"
)
func main() {
	introducerAddr := "192.168.0.183:10001"
	intro, e := ua.UDPResolveAddr(introducerAddr)
	if e != nil {
		log.Fatalln("failed to UDPResolveAddr")
	}
	localPort:= 10002
	m := ua.CreateNode()
	gr, _, e := m.JoinGroup(intro, "StoreGroup1", true, "192.168.0.183",localPort, 100, 10, 10)
	if e != nil {
		fmt.Println(e)
		log.Fatalln("member failed to JoinGroup")
	}
	fmt.Println("Tasks sender joined group")
	tasks := []string{}
	for i := 0; i < 100; i++ {
		tasks = append(tasks, strconv.Itoa(i))
	}
	start := time.Now()
	result := gr.STasks2GroupLB(tasks)
	duration := time.Since(start)
	fmt.Println("Time: ", duration)
	fmt.Println("STasks2GroupLB result:", result)
	fmt.Println("STasks2GroupLB result length:", len(result))
}