package main
import (
	"fmt"
	"Uactor/ua"
	"time"
	"log"
)
func main() {
	introducerAddr := "192.168.0.183:10001"
	intro, e := ua.UDPResolveAddr(introducerAddr)
	if e != nil {
		log.Fatalln("failed to UDPResolveAddr")
	}
	startPort := 10003
	membersNumber := 63
	for i := startPort; i < startPort+membersNumber-1; i++ {
		m := ua.CreateNode()
		gr, mailbox, e := m.JoinGroup(intro, "StoreGroup1", false, "192.168.0.183",i, 100, 10, 10)
		if e != nil {
			fmt.Println(e)
			log.Fatalln("member failed to JoinGroup")
		}
		go func() {
			for m := range mailbox {
				mb := string(m.Body)
				fmt.Println("received", mb)
				if m.NeedReply {
					_ = gr.Reply(m, []byte(task(mb)))
				}
			}
		}()
	}
	fmt.Println("Created worker", membersNumber)
	forever := make(chan bool)
	<-forever
}
func task(s string) string {
	time.Sleep(1*time.Second)
	return s+"Reply"
}