package main
import (
	"fmt"
	"Uactor/ua"
	"time"
	"log"
)
func main() {
	m1 := ua.CreateNode()
	gr, mailbox1, e := m1.CreateGroup("StoreGroup1", "192.168.0.183", 10001, 100, 10, 10)
	if e != nil {
		fmt.Println(e)
		log.Fatalln("failed to CreateGroup")
	}
	go func() {
		for m := range mailbox1 {
			mb := string(m.Body)
			fmt.Println("received", mb)
			if m.NeedReply {
				_ = gr.Reply(m, []byte(task(mb)))
			}
		}
	}()
	fmt.Println("Member created group")
	forever := make(chan bool)
	<-forever
}
func task(s string) string {
	time.Sleep(1*time.Second)
	return s+"Reply"
}