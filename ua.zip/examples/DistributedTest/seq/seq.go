package main
import (
	"fmt"
	"time"
	"strconv"
)
func main() {
	tasks := []string{}
	for i := 0; i < 100; i++ {
		tasks = append(tasks, strconv.Itoa(i))
	}
	start := time.Now()
	result := make(map[string]string)
	for _, t := range tasks {
		result[t]=task(t)
	}
	fmt.Println(result)
	duration := time.Since(start)
    fmt.Println("Time: ", duration)
}
func task(s string) string {
	time.Sleep(1*time.Second)
	return s+"Reply"
}