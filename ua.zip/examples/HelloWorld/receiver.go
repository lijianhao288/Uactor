package main
import (
    "Uactor/ua"
    "fmt"
)
func main() {
    _, mailbox, _ := ua.Listen("[::1]",1231, 100, 10)
    go func() {
        for m := range mailbox {
            fmt.Println("Received", string(m.Body))
        }
    }()
    forever := make(chan bool)
    <-forever
}