package main
import (
    "Uactor/ua"
    "fmt"
)
func main() {
    c, _, _ := ua.Listen("[::1]", 1232, 100, 10)
    remote, _ := ua.UDPResolveAddr("[::1]:1231")
    m := "Hello World"
    _, _ = c.Send(remote, "", []byte(m))
    fmt.Println("Sent", m)
}