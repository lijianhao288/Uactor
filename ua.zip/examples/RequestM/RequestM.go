package main
import (
	"Uactor/ua"
	"fmt"
	"time"
)
func main() {
	localPort1 := 1232
	c1, mailbox1, _ := ua.Listen("[::1]", localPort1, 100, 10)
	go func() {
		for m := range mailbox1 {
			fmt.Println(localPort1, "Received", m)
			if m.NeedReply {
				_ = c1.Reply(m, []byte("1232 reply"))
			}
		}
	}()
	localPort2 := 1233
	c2, mailbox2, _ := ua.Listen("[::1]", localPort2, 100, 10)
	go func() {
		for m := range mailbox2 {
			fmt.Println(localPort2, "Received", m)
			if m.NeedReply {
				_ = c2.Reply(m, []byte("1233 reply"))
			}
		}
	}()
	localPort3 := 1234
	_, mailbox3, _ := ua.Listen("[::1]", localPort3, 100, 10)
	go func() {
		for m := range mailbox3 {
			fmt.Println(localPort3, "Received", m)

		}
	}()
	localPort4 := 1235
	c, _, _ := ua.Listen("[::1]", localPort4, 100, 10)
	remoteAddrs := []string{"[::1]:1232", "[::1]:1233", "[::1]:1234"}
	dests, e := ua.UDPResolveAddrs(remoteAddrs)
	if e != nil {
		fmt.Println(e)
	}
	result := c.RequestM(dests, "", []byte("Request"), 2*time.Second)
	fmt.Println(result)
	forever := make(chan bool)
	<-forever
}