package main
import (
	"Uactor/ua"
	"fmt"
)
func main() {
    m1 := ua.CreateNode()
    gr1, mailbox, _ := m1.CreateGroup("StoreGroup1", "[::1]", 1231, 100, 10, 10)
    go func() {
        for m := range mailbox {
            fmt.Println("M1 mailbox received", string(m.Body),
            "from", m.Sender)
            if m.NeedAck {
                gr1.Ack(m)
            }
        }
    }()
    m1log, _ := gr1.GroupSub("log")
    go func() {
        for m := range m1log {
            fmt.Println("M1 log channel received",
            string(m.Body),"from", m.Sender)
            if m.NeedAck {
                gr1.Ack(m)
            }
        }
    }()
    introducerAddr := "[::1]:1231"
    intro, _ := ua.UDPResolveAddr(introducerAddr)
    m2 := ua.CreateNode()
    gr2, mailbox2, _ := m2.JoinGroup(intro, "StoreGroup1", false, "[::1]", 1232, 
    100, 10, 10)
    go func() {
        for m := range mailbox2 {
            fmt.Println("M2 mailbox received", string(m.Body),
            "from", m.Sender)
            if m.NeedAck {
                gr2.Ack(m)
            }
        }
    }()
    c1 := ua.CreateNode()
    c1g1, mailbox3, _ := c1.JoinGroup(intro, "StoreGroup1", true, "[::1]",
    1233, 100, 10, 10)
    go func() {
        for m := range mailbox3 {
            fmt.Println("C1 mailbox received", string(m.Body),
            "from", m.Sender)
            if m.NeedAck {
                gr2.Ack(m)
            }
        }
    }()
    fmt.Println("GroupRelations:")
    fmt.Println("Member1:", gr1)
    fmt.Println("Member2:", gr2)
    fmt.Println("Client1:", c1g1)
    gr1.GroupSendBC([]byte("M1 bc"))
    gr2.GroupSendBC([]byte("M2 bc"))
    c1g1.GroupSendBC([]byte("C1 bc"))
    forever := make(chan bool)
    <-forever
}