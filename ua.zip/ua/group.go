package ua
import (
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"sync"
	"time"
)
const joinTag = "#JOIN"
const clientTag = "#CLIENT"
const memberTag = "#MEMBER"
const subTag = "#SUB"
const subCancelTag = "#SUBCANCEL"
const handleChannelSize = 10
const subChannelSize = 10
const retryInterval = 2 * time.Second
const requestTimeout = 110 * time.Second
const retryTimes = 3
const plus = "+"
const minus = "-"
const client = "C"
const member = "M"
type Node struct {
	groupMap map[string]*GroupRelation
	groupMutex sync.RWMutex
}
type GroupRelation struct {
	communicator *Communicator
	isClient bool
	Clients      []*net.UDPAddr
	clientsMutex sync.RWMutex
	Members      []*net.UDPAddr
	membersMutex sync.RWMutex
	RoutingMap   map[string][]*net.UDPAddr
	routingMutex sync.RWMutex
	rrIndex      int
	rrIndexMutex sync.Mutex
}
type groupStructure struct {
	Clients    []*net.UDPAddr
	Members    []*net.UDPAddr
	RoutingMap map[string][]*net.UDPAddr
}
func gsToJson(gs groupStructure) ([]byte, error) {
	r, err := json.Marshal(&gs)
	if err != nil {
		return nil, errors.New("Failed to marshal")
	}
	return r, nil
}
func jsonToGs(j []byte) (*groupStructure, error) {
	var gs groupStructure
	err := json.Unmarshal(j, &gs)
	if err != nil {
		fmt.Println(err)
		return nil, errors.New("Failed to unmarshal")
	}
	return &gs, nil
}
func CreateNode() *Node {
	return &Node{groupMap: make(map[string]*GroupRelation)}
}
func (n *Node) isGroupNameRepeat(groupName string) bool {
	n.groupMutex.RLock()
	_, ok := n.groupMap[groupName]
	n.groupMutex.RUnlock()
	return ok
}
func (n *Node) CreateGroup(groupName string, ip string,localPort int, mailboxSize int, receiveGoroutineNumber int, groupGroutineNumber int) (*GroupRelation, <-chan Msg, error) {
	if n.isGroupNameRepeat(groupName) {
		return nil, nil, errors.New("Group name repeat")
	}
	c, mailbox, e := Listen(ip, localPort, mailboxSize, receiveGoroutineNumber)
	if e != nil {
		fmt.Println(e)
		return nil, nil, errors.New("Failed to Listen")
	}
	gr := &GroupRelation{communicator: c, isClient: false, RoutingMap: make(map[string][]*net.UDPAddr)}
	n.groupMutex.Lock()
	n.groupMap[groupName] = gr
	n.groupMutex.Unlock()
	for i := 0; i < groupGroutineNumber; i++ {
		gr.handleMember()
	}
	go gr.handleJoin()
	return gr, mailbox, nil
}
func (n *Node) LeaveGroup(groupName string) error {
	n.groupMutex.RLock()
	gr, ok := n.groupMap[groupName]
	n.groupMutex.RUnlock()
	if !ok {
		return errors.New("No such a group")
	}
	tag := ""
	if gr.isClient {
		tag = clientTag
	} else {
		tag = memberTag
		gr.clientsMutex.RLock()
		gr.communicator.SendGM(gr.Clients, tag, []byte(minus), retryInterval, retryTimes)
		gr.clientsMutex.RUnlock()
	}
	gr.membersMutex.RLock()
	gr.communicator.SendGM(gr.Members, tag, []byte(minus), retryInterval, retryTimes)
	gr.membersMutex.RUnlock()
	e := gr.communicator.Close()
	if e != nil {
		return errors.New("Failed to close the communicator")
	}
	n.groupMutex.Lock()
	delete(n.groupMap, groupName)
	n.groupMutex.Unlock()
	return nil
}
func (n *Node) Close() error {
	n.groupMutex.Lock()
	for k, _ := range n.groupMap {
		e := n.LeaveGroup(k)
		if e != nil {
			return errors.New("Failed to leave a group")
		}
	}
	n.groupMutex.Unlock()
	return nil
}
func (n *Node) JoinGroup(introducer *net.UDPAddr, groupName string, isClient bool, ip string,localPort int, mailboxSize int, receiveGoroutineNumber int, groupGroutineNumber int) (*GroupRelation, <-chan Msg, error) {
	if n.isGroupNameRepeat(groupName) {
		return nil, nil, errors.New("Group name repeat")
	}
	c, mailbox, e := Listen(ip, localPort, mailboxSize, receiveGoroutineNumber)
	if e != nil {
		return nil, nil, errors.New("Failed to Listen")
	}
	reqbody := ""
	if isClient {
		reqbody = client
	} else {
		reqbody = member
	}
	reply, e := c.Request(introducer, joinTag, []byte(reqbody), requestTimeout)
	if e != nil {
		fmt.Println(e)
		return nil, nil, errors.New("Failed to request")
	}
	gs, e := jsonToGs(reply.Body)
	if e != nil {
		fmt.Println(e)
		return nil, nil, errors.New("Failed to jsonToGs")
	}
	gr := &GroupRelation{communicator: c, isClient: isClient, Clients: gs.Clients, Members: gs.Members, RoutingMap: gs.RoutingMap}
	if isClient {
		for i := 0; i < groupGroutineNumber; i++ {
			gr.handleClient()
		}
	} else {
		for i := 0; i < groupGroutineNumber; i++ {
			gr.handleMember()
		}
		go gr.handleJoin()
	}
	n.groupMutex.Lock()
	n.groupMap[groupName] = gr
	n.groupMutex.Unlock()
	if isClient {
		gr.membersMutex.RLock()
		r := gr.communicator.RequestM(gr.Members, clientTag, []byte(plus), requestTimeout)
		if len(r) != len(gr.Members) {
			return nil, nil, errors.New("Failed to inform Members")
		}
		gr.membersMutex.RUnlock()
	} else {
		gr.membersMutex.RLock()
		r1 := gr.communicator.RequestM(gr.Members, memberTag, []byte(plus), requestTimeout)
		if len(r1) != len(gr.Members) {
			return nil, nil, errors.New("Failed to inform Members")
		}
		gr.membersMutex.RUnlock()
		gr.clientsMutex.RLock()
		r2 := gr.communicator.RequestM(gr.Clients, memberTag, []byte(plus), requestTimeout)
		if len(r2) != len(gr.Clients) {
			return nil, nil, errors.New("Failed to inform Clients")
		}
		gr.clientsMutex.RUnlock()
	}
	return gr, mailbox, nil
}
func (g *GroupRelation) handleMember() {
	go g.handleClientChange()
	go g.handleMemberChange()
	go g.handleSub()
	go g.handleSubCancel()
}
func (g *GroupRelation) handleClient() {
	go g.handleMemberChange()
	go g.handleSub()
	go g.handleSubCancel()
}
func (g *GroupRelation) handleJoin() {
	ch, e := g.communicator.sub(joinTag, handleChannelSize)
	if e != nil {
		fmt.Println("Failed to Sub", e)
	}
	for m := range ch {
		if m.NeedReply {
			g.membersMutex.RLock()
			members := make([]*net.UDPAddr, len(g.Members))
			copy(members, g.Members)
			g.membersMutex.RUnlock()
			members = append(members, g.communicator.LocalAddr)
			if string(m.Body) == client {
				gs := groupStructure{nil, members, g.RoutingMap}
				g.routingMutex.RLock()
				b, e := gsToJson(gs)
				g.routingMutex.RUnlock()
				if e != nil {
					fmt.Println("Fail to gsToJson")
					continue
				}
				e = g.communicator.Reply(m, b)
				if e != nil {
					fmt.Println("Fail to Reply")
					continue
				}
			}
			if string(m.Body) == member {
				gs := groupStructure{g.Clients, members, g.RoutingMap}
				g.clientsMutex.RLock()
				g.routingMutex.RLock()
				b, e := gsToJson(gs)
				g.clientsMutex.RUnlock()
				g.routingMutex.RUnlock()
				if e != nil {
					fmt.Println("Fail to gsToJson")
					continue
				}
				e = g.communicator.Reply(m, b)
				if e != nil {
					fmt.Println("Fail to Reply")
					continue
				}
			}
		}
	}
}
func (g *GroupRelation) handleClientChange() {
	ch, e := g.communicator.sub(clientTag, handleChannelSize)
	if e != nil {
		fmt.Println("Failed to Sub", e)
	}
	for m := range ch {
		if string(m.Body) == plus {
			g.clientsMutex.Lock()
			g.Clients = append(g.Clients, m.Sender)
			g.clientsMutex.Unlock()
		}
		if string(m.Body) == minus {
			g.clientsMutex.Lock()
			g.Clients = DeleteAddr(g.Clients, m.Sender)
			g.clientsMutex.Unlock()
		}
		if m.NeedAck {
			e := g.communicator.Ack(m)
			if e != nil {
				fmt.Println("Failed to ack, in handleClientChange")
			}
		}
		if m.NeedReply {
			e = g.communicator.Reply(m, []byte{})
			if e != nil {
				fmt.Println("Failed to reply, in handleClientChange")
			}
		}
	}
}
func (g *GroupRelation) handleMemberChange() {
	ch, e := g.communicator.sub(memberTag, handleChannelSize)
	if e != nil {
		fmt.Println("Failed to Sub", e)
	}
	for m := range ch {
		if string(m.Body) == plus {
			g.membersMutex.Lock()
			g.Members = append(g.Members, m.Sender)
			g.membersMutex.Unlock()
		}
		if string(m.Body) == minus {
			g.membersMutex.Lock()
			g.Members = DeleteAddr(g.Members, m.Sender)
			g.membersMutex.Unlock()
		}
		if m.NeedAck {
			e := g.communicator.Ack(m)
			if e != nil {
				fmt.Println("Failed to ack, in handleMemberChange")
			}
		}
		if m.NeedReply {
			e = g.communicator.Reply(m, []byte{})
			if e != nil {
				fmt.Println("Failed to reply, in handleClientChange")
			}
		}
	}
}
func (g *GroupRelation) handleSub() {
	ch, e := g.communicator.sub(subTag, handleChannelSize)
	if e != nil {
		fmt.Println("Failed to Sub", e)
	}
	for m := range ch {
		tag := string(m.Body)
		g.routingMutex.Lock()
		g.RoutingMap[tag] = append(g.RoutingMap[tag], m.Sender)
		g.routingMutex.Unlock()
		if m.NeedAck {
			e := g.communicator.Ack(m)
			if e != nil {
				fmt.Println("Failed to ack, in handleSub")
			}
		}
	}
}
func (g *GroupRelation) handleSubCancel() {
	ch, e := g.communicator.sub(subCancelTag, handleChannelSize)
	if e != nil {
		fmt.Println("Failed to Sub", e)
	}
	for m := range ch {
		tag := string(m.Body)
		g.routingMutex.Lock()
		g.RoutingMap[tag] = DeleteAddr(g.RoutingMap[tag], m.Sender)
		g.routingMutex.Unlock()
		if m.NeedAck {
			e := g.communicator.Ack(m)
			if e != nil {
				fmt.Println("Failed to ack, in handleSubCancel")
			}
		}
	}
}
func (g *GroupRelation) GroupSub(tag string) (<-chan Msg, error) {
	if g.isClient {
		return nil, errors.New("Client can not GroupSub")
	}
	subCh, e := g.communicator.sub(tag, subChannelSize)
	if e != nil {
		return nil, errors.New("Failed to Sub")
	}
	g.routingMutex.Lock()
	g.RoutingMap[tag] = append(g.RoutingMap[tag], g.communicator.LocalAddr)
	g.routingMutex.Unlock()
	g.membersMutex.RLock()
	g.communicator.SendGM(g.Members, subTag, []byte(tag), retryInterval, retryTimes)
	g.membersMutex.RUnlock()
	g.clientsMutex.RLock()
	g.communicator.SendGM(g.Clients, subTag, []byte(tag), retryInterval, retryTimes)
	g.clientsMutex.RUnlock()
	return subCh, nil
}
func (g *GroupRelation) GroupSubCancel(tag string) error {
	if g.isClient {
		return errors.New("Client can not GroupSubCancel")
	}
	g.communicator.subCancel(tag)
	g.routingMutex.Lock()
	g.RoutingMap[tag] = DeleteAddr(g.RoutingMap[tag], g.communicator.LocalAddr)
	g.routingMutex.Unlock()
	g.membersMutex.RLock()
	g.communicator.SendGM(g.Members, subCancelTag, []byte(tag), retryInterval, retryTimes)
	g.membersMutex.RUnlock()
	g.clientsMutex.RLock()
	g.communicator.SendGM(g.Clients, subCancelTag, []byte(tag), retryInterval, retryTimes)
	g.clientsMutex.RUnlock()
	return nil
}
func (g *GroupRelation) roundRobinMember() *net.UDPAddr {
	g.membersMutex.RLock()
	members := g.Members
	g.rrIndexMutex.Lock()
	r := members[g.rrIndex]
	if g.rrIndex >= len(members)-1 {
		g.rrIndex = 0
	} else {
		g.rrIndex++
	}
	g.membersMutex.RUnlock()
	g.rrIndexMutex.Unlock()
	return r
}
func (g *GroupRelation) GroupSendLB(body []byte) {
	dest := g.roundRobinMember()
	g.communicator.SendG(dest, "", body, retryInterval, retryTimes)
}
func (g *GroupRelation) GroupSendBC(body []byte) {
	g.membersMutex.RLock()
	members := g.Members
	g.membersMutex.RUnlock()
	g.communicator.SendGM(members, "", body, retryInterval, retryTimes)
}
func (g *GroupRelation) GroupSendPub(tag string, body []byte) {
	g.routingMutex.RLock()
	dests := g.RoutingMap[tag]
	g.routingMutex.RUnlock()
	g.communicator.SendGM(dests, tag, body, retryInterval, retryTimes)
}
func (g *GroupRelation) GroupRequestLB(body []byte) (*Msg, error) {
	dest := g.roundRobinMember()
	reply, e := g.communicator.Request(dest, "", body, requestTimeout)
	if e != nil {
		return nil, errors.New("Failed to request")
	}
	return reply, nil
}
func (g *GroupRelation)STasks2GroupLB(requests []string) map[string]string {
	result := make(map[string]string)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, r := range requests {
		wg.Add(1)
		go func(re string) {
			defer wg.Done()
			reply, e := g.GroupRequestLB([]byte(re))
			if e == nil {
				mu.Lock()
				result[re] = string(reply.Body)
				mu.Unlock()
			}
		}(r)
	}
	wg.Wait()
	return result
}
func (g *GroupRelation) GroupRequestBC(body []byte) map[*net.UDPAddr]*Msg {
	g.membersMutex.RLock()
	members := g.Members
	g.membersMutex.RUnlock()
	result := g.communicator.RequestM(members, "", body, requestTimeout)
	return result
}
func (g *GroupRelation) GroupRequestPub(tag string, body []byte) map[*net.UDPAddr]*Msg {
	g.routingMutex.RLock()
	dests := g.RoutingMap[tag]
	g.routingMutex.RUnlock()
	result := g.communicator.RequestM(dests, tag, body, requestTimeout)
	return result
}
func (c *GroupRelation) Reply(request Msg, replyBody []byte) error {
	return c.communicator.Reply(request, replyBody)
}
func (c *GroupRelation) Ack(request Msg) error {
	return c.communicator.Ack(request)
}
func (g *GroupRelation) GetMemberLen() int {
	g.membersMutex.RLock()
	l := len(g.Members)
	g.membersMutex.RUnlock()
	return l
}
func (g *GroupRelation) GetClientLen() int {
	g.clientsMutex.RLock()
	l := len(g.Clients)
	g.clientsMutex.RUnlock()
	return l
}
func (g *GroupRelation) GetSubLen(tag string) int {
	var r int
	g.routingMutex.RLock()
	v, ok := g.RoutingMap[tag]
	if ok {
		r = len(v)
	}
	g.routingMutex.RUnlock()
	return r
}
func (g *GroupRelation) GetMembersCopy() []*net.UDPAddr {
	g.membersMutex.RLock()
	r := make([]*net.UDPAddr, len(g.Members))
	copy(r, g.Members)
	g.membersMutex.RUnlock()
	return r
}
func (g *GroupRelation) GetClientsCopy() []*net.UDPAddr {
	g.clientsMutex.RLock()
	r := make([]*net.UDPAddr, len(g.Members))
	copy(r, g.Clients)
	g.clientsMutex.RUnlock()
	return r
}
func (g *GroupRelation) GetRoutingMapCopy() map[string][]*net.UDPAddr {
	r := make(map[string][]*net.UDPAddr)
	g.routingMutex.RLock()
	for k, v := range g.RoutingMap {
		r[k] = v
	}
	g.routingMutex.RUnlock()
	return r
}