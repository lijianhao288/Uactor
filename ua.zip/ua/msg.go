package ua
import (
	"encoding/json"
	"errors"
	"net"
	"os"
	"time"
)
const msgFolder = "failedSendG/"
type Msg struct {
	MsgId     string
	Body      []byte
	Tag       string
	Sender    *net.UDPAddr
	NeedAck   bool
	NeedReply bool
}
type MsgSave struct {
	Msg  Msg
	Time string
	Note string
}
func MsgToJson(m Msg) ([]byte, error) {
	r, err := json.Marshal(&m)
	if err != nil {
		return nil, errors.New("Failed to marshal")
	}
	return r, nil
}
func MsgSaveToJson(ms MsgSave) ([]byte, error) {
	r, err := json.Marshal(&ms)
	if err != nil {
		return nil, errors.New("Failed to marshal")
	}
	return r, nil
}
func JsonToMsg(j []byte) (*Msg, error) {
	var m Msg
	err := json.Unmarshal(j, &m)
	if err != nil {
		return nil, errors.New("Failed to unmarshal")
	}
	return &m, nil
}
func JsonToMsgSave(j []byte) (*MsgSave, error) {
	var ms MsgSave
	err := json.Unmarshal(j, &ms)
	if err != nil {
		return nil, errors.New("Failed to unmarshal")
	}
	return &ms, nil
}
func SaveMsg(m Msg, note string) (int, error) {
	if !locate(msgFolder) {
		err := os.MkdirAll(msgFolder, os.ModePerm)
		if err != nil {
			return 0, errors.New("Failed to MkdirAll")
		}
	}
	if locate(msgFolder + m.MsgId) {
		return 0, errors.New("MsgId repeat")
	}
	f, err := os.Create(msgFolder + m.MsgId)
	if err != nil {
		return 0, errors.New("Failed to create file")
	}
	defer f.Close()
	ms := MsgSave{m, time.Now().String(), note}
	j, err := MsgSaveToJson(ms)
	if err != nil {
		return 0, err
	}
	n, err := f.Write(j)
	if err != nil {
		return 0, errors.New("Failed to write file")
	}
	f.Sync()
	return n, nil
}
func ReadMsgFile(msgId string) (*Msg, error) {
	j, err := os.ReadFile(msgFolder + msgId)
	if err != nil {
		return nil, errors.New("Failed to ReadFile")
	}
	ms, err := JsonToMsgSave(j)
	if err != nil {
		return nil, err
	}
	return &ms.Msg, nil
}
func DeleteMsgFolder() error {
	err := os.RemoveAll(msgFolder)
	if err != nil {
		return errors.New("Failed to RemoveAll")
	}
	return nil
}
func locate(name string) bool {
	_, err := os.Stat(name)
	return !os.IsNotExist(err)
}