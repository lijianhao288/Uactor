package ua
import (
	"errors"
	"fmt"
	"net"
	"strings"
	"sync"
	"time"
)
type Communicator struct {
	mailbox chan Msg
	LocalAddr *net.UDPAddr
	LocalConn *net.UDPConn
	submap map[string]chan Msg
	quit chan struct{}
	subMutex sync.RWMutex
	wg sync.WaitGroup
}
func Listen(ip string, port int, mailboxSize int, receiveGoroutineNumber int) (*Communicator, <-chan Msg, error) {
	localAddr, localConn, e := UDPListenOnPort(ip,port)
	if e != nil {
		fmt.Println(e)
		return nil, nil, errors.New("Failed to ListenOnPort")
	}
	mailbox := make(chan Msg, mailboxSize)
	c := Communicator{mailbox: mailbox, LocalAddr: localAddr,
		LocalConn: localConn, submap: make(map[string]chan Msg), quit: make(chan struct{})}
	for i := 0; i < receiveGoroutineNumber; i++ {
		go receiveHandle(i, &c)
	}
	return &c, mailbox, nil
}
func receiveHandle(i int, c *Communicator) {
	for {
		select {
		case <-c.quit:
			return
		default:
			b, senderAddr, err := UDPReceive(c.LocalConn)
			if err != nil {
				continue
			}
			m, err := JsonToMsg(b)
			if err != nil {
				fmt.Println("fail to JsonToMsg:", err)
				continue
			}
			m.Sender = senderAddr
			c.subMutex.RLock()
			v, ok := c.submap[m.Tag]
			c.subMutex.RUnlock()
			if ok {
				v <- *m
			} else {
				c.mailbox <- *m
			}
		}
	}
}
func (c *Communicator) Close() error {
	c.wg.Wait()
	e := c.LocalConn.Close()
	if e != nil {
		errors.New("Failed to close udp conn")
	}
	close(c.quit)
	close(c.mailbox)
	for _, ch := range c.submap {
		close(ch)
	}
	return nil
}
func (c *Communicator) Sub(tag string, channelSize int) (<-chan Msg, error) {
	if strings.HasPrefix(tag, "#") {
		return nil, errors.New("Tag with # prefix is reserved")
	}
	ch, e := c.sub(tag, channelSize)
	return ch, e
}
func (c *Communicator) sub(tag string, channelSize int) (<-chan Msg, error) {
	if tag == "" {
		return nil, errors.New("Tag is empty string")
	}
	c.subMutex.RLock()
	v, ok := c.submap[tag]
	c.subMutex.RUnlock()
	if ok {
		return v, nil
	} else {
		subchan := make(chan Msg, channelSize)
		c.subMutex.Lock()
		c.submap[tag] = subchan
		c.subMutex.Unlock()
		return subchan, nil
	}
}
func (c *Communicator) SubCancel(tag string) error {
	if strings.HasPrefix(tag, "#") {
		return errors.New("Tag with # prefix is reserved")
	}
	c.subCancel(tag)
	return nil
}
func (c *Communicator) subCancel(tag string) {
	c.subMutex.Lock()
	delete(c.submap, tag)
	c.subMutex.Unlock()
}
func (c *Communicator) sendMsg(dest *net.UDPAddr, m Msg) (int, error) {
	data, e := MsgToJson(m)
	if e != nil {
		return 0, errors.New("Failed to MsgToJson")
	}
	if len(data) > MTU {
		return 0, errors.New("The data length exceeds MTU")
	}
	n, e := c.LocalConn.WriteTo(data, dest)
	if e != nil {
		fmt.Println(e)
		return 0, errors.New("Failed to write")
	}
	return n, nil
}
func (c *Communicator) Send(dest *net.UDPAddr, tag string, body []byte) (int, error) {
	m := Msg{"", body, tag, nil, false, false}
	return c.sendMsg(dest, m)
}
func (c *Communicator) SendM(dests []*net.UDPAddr, tag string, body []byte) *map[*net.UDPAddr]error {
	result := make(map[*net.UDPAddr]error)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, dest := range dests {
		wg.Add(1)
		go func(dest *net.UDPAddr) {
			defer wg.Done()
			_, e := c.Send(dest, tag, body)
			mu.Lock()
			result[dest] = e
			mu.Unlock()
		}(dest)
	}
	wg.Wait()
	return &result
}
func (c *Communicator) SendG(dest *net.UDPAddr, tag string, body []byte, retryInterval time.Duration, retryTimes int) {
	mid := GenId()
	m := Msg{mid, body, tag, nil, true, false}
	ackC, e := c.sub(mid, 1)
	if e != nil {
		_, e := SaveMsg(m, "Sub failed, the mid start with #")
		if e != nil {
			fmt.Println("Failed to SaveMsg", e)
		}
	}
	c.wg.Add(1)
	go func(dest *net.UDPAddr, retryInterval time.Duration, retryTimes int, m Msg, c *Communicator) {
		for i := 0; i < retryTimes; i++ {
			_, e := c.sendMsg(dest, m)
			if e != nil {
				continue
			}
			select {
			case ack := <-ackC:
				if dest.String() != ack.Sender.String() {
					hint := "Being disturbed, reply sender != dest"
					fmt.Println(hint)
					_, e := SaveMsg(m, hint)
					if e != nil {
						fmt.Println("Failed to SaveMsg", e)
					}
				}
				c.subCancel(mid)
				c.wg.Done()
				return
			case <-time.After(retryInterval):
			}
		}
		_, e := SaveMsg(m, "All the retries failed")
		if e != nil {
			fmt.Println("Failed to SaveMsg", e)
		}
		c.wg.Done()
	}(dest, retryInterval, retryTimes, m, c)
}
func (c *Communicator) SendGM(dests []*net.UDPAddr, tag string, body []byte, retryInterval time.Duration, retryTimes int) {
	for _, dest := range dests {
		go func(dest *net.UDPAddr) {
			c.SendG(dest, tag, body, retryInterval, retryTimes)
		}(dest)
	}
}
func (c *Communicator) Request(dest *net.UDPAddr, tag string, body []byte, timeout time.Duration) (*Msg, error) {
	mid := GenId()
	m := Msg{mid, body, tag, nil, false, true}
	replyC, e := c.sub(mid, 1)
	if e != nil {
		return nil, errors.New("Sub faild. The tag may start with #")
	}
	_, e = c.sendMsg(dest, m)
	if e != nil {
		fmt.Println(e)
		return nil, errors.New("Failed to sendMsg")
	}
	select {
	case reply := <-replyC:
		c.subCancel(mid)
		if dest.String() != reply.Sender.String() {
			return nil, errors.New("Being disturbed, reply sender != dest")
		}
		return &reply, nil
	case <-time.After(timeout):
		return nil, errors.New("Time out")
	}
}
func (c *Communicator) RequestM(dests []*net.UDPAddr, tag string, body []byte, timeout time.Duration) map[*net.UDPAddr]*Msg {
	result := make(map[*net.UDPAddr]*Msg)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, dest := range dests {
		wg.Add(1)
		go func(dest *net.UDPAddr) {
			defer wg.Done()
			reply, _ := c.Request(dest, tag, body, timeout)
			mu.Lock()
			result[dest] = reply
			mu.Unlock()
		}(dest)
	}
	wg.Wait()
	return result
}
func (c *Communicator) RequestAsync(dest *net.UDPAddr, tag string, body []byte, timeout time.Duration, replyTo chan Msg) error {
	mid := GenId()
	m := Msg{mid, body, tag, nil, false, true}
	replyC, e := c.sub(mid, 1)
	if e != nil {
		return errors.New("Sub faild. The tag may start with #")
	}
	_, e = c.sendMsg(dest, m)
	if e != nil {
		return errors.New("Failed to sendMsg")
	}
	c.wg.Add(1)
	go func(replyC <-chan Msg, mid string, timeout time.Duration, c *Communicator) {
		select {
		case reply := <-replyC:
			c.subCancel(mid)
			if dest.String() != reply.Sender.String() {
				c.wg.Done()
				return
			}
			replyTo <- reply
			c.wg.Done()
			return
		case <-time.After(timeout):
			fmt.Println("RequestAsync failed, timeout")
			c.wg.Done()
			return
		}
	}(replyC, mid, timeout, c)
	return nil
}
func (c *Communicator) RequestAsyncM(dests []*net.UDPAddr, tag string, body []byte, timeout time.Duration, replyTo chan Msg) *map[*net.UDPAddr]error {
	result := make(map[*net.UDPAddr]error)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, dest := range dests {
		wg.Add(1)
		go func(dest *net.UDPAddr) {
			defer wg.Done()
			e := c.RequestAsync(dest, tag, body, timeout, replyTo)
			mu.Lock()
			result[dest] = e
			mu.Unlock()
		}(dest)
	}
	wg.Wait()
	return &result
}
func (c *Communicator) Reply(request Msg, replyBody []byte) error {
	requestMid := request.MsgId
	if requestMid == "" {
		return errors.New("Request msgId missing")
	}
	m := Msg{"", replyBody, requestMid, nil, false, false}
	_, e := c.sendMsg(request.Sender, m)
	if e != nil {
		return errors.New("Failed to sendMsg")
	}
	return nil
}
func (c *Communicator) Ack(request Msg) error {
	requestMid := request.MsgId
	if requestMid == "" {
		return errors.New("msgId missing")
	}
	m := Msg{"", []byte(""), requestMid, nil, false, false}
	_, e := c.sendMsg(request.Sender, m)
	if e != nil {
		return errors.New("Failed to sendMsg")
	}
	return nil
}