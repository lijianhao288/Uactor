package ua
import (
	"errors"
	"net"
	"strconv"
	"sync"
	"fmt"
)
const MTU = 65000
func UDPListenOnPort(ip string, port int) (*net.UDPAddr, *net.UDPConn, error) {
	if port < 1024 || port > 49151 {
		return nil, nil, errors.New("Invalid port number")
	}
	localAddr, e := UDPResolveAddr(ip+":"+strconv.Itoa(port))
	if e != nil {
		return nil, nil, errors.New("Failed to Resolve UDP Address")
	}
	localConn, e := net.ListenUDP("udp", localAddr)
	if e != nil {
		return nil, nil, errors.New("Failed to Listen UDP")
	}
	return localAddr, localConn, nil
}
func UDPSend(c *net.UDPConn, dest *net.UDPAddr, data []byte) (int, error) {
	if len(data) > MTU {
		return 0, errors.New("The data length exceeds MTU")
	}
	n, e := c.WriteTo(data, dest)
	if e != nil {
		return 0, errors.New("Failed to write")
	}
	return n, nil
}
func UDPResolveAddr(ad string) (*net.UDPAddr, error) {
	r, e := net.ResolveUDPAddr("udp", ad)
	if e != nil {
		fmt.Println(e)
		return nil, errors.New("Failed to Resolve UDP Address")
	}
	return r, nil
}
func UDPResolveAddrs(ads []string) ([]*net.UDPAddr, error) {
	result := []*net.UDPAddr{}
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, v := range ads {
		wg.Add(1)
		go func(ad string) {
			defer wg.Done()
			r, e := UDPResolveAddr(ad)
			if e == nil {
				mu.Lock()
				result = append(result, r)
				mu.Unlock()
			}
		}(v)

	}
	wg.Wait()
	if len(result) == len(ads) {
		return result, nil
	} else {
		return nil, errors.New("Failed to Resolve All the Addresses")
	}
}
func DeleteAddr(addrs []*net.UDPAddr, addr *net.UDPAddr) []*net.UDPAddr {
	for i, v := range addrs {
		if v == addr {
			addrs[i] = addrs[len(addrs)-1]
			return addrs[:len(addrs)-1]
		}
	}
	return addrs
}
func UDPReceive(c *net.UDPConn) ([]byte, *net.UDPAddr, error) {
	buf := make([]byte, MTU)
	n, senderAddr, e := c.ReadFromUDP(buf)
	if e != nil {
		return nil, nil, errors.New("Failed to read from udp port")
	}
	return buf[:n], senderAddr, nil
}