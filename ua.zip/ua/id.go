package ua
import (
	"github.com/google/uuid"
)
func GenId() string {
	id := uuid.New()
	return id.String()
}