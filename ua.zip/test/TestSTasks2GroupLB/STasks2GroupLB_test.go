package testSTasks2GroupLB
import (
	"Uactor/ua"
	"fmt"
	"testing"
)
func TestSTasks2GroupLB(t *testing.T) {
	membersNumber := 6
	clientsNumber := 3
	fmt.Println("membersNumber", membersNumber)
	fmt.Println("clientsNumber", clientsNumber)
	m1 := ua.CreateNode()
	gr1, mailbox1, e := m1.CreateGroup("StoreGroup1","[::1]", 1231, 100, 10, 10)
	if e != nil {
		t.Errorf("failed to CreateGroup")
	}
	go func() {
		for m := range mailbox1 {
			fmt.Println("1231 received", string(m.Body))
			if m.NeedReply {
				e = gr1.Reply(m, append(m.Body,[]byte("Reply")...))
			}
		}
	}()
	fmt.Println("Member created group, GroupRelation variable: gr1")
	introducerAddr := "[::1]:1231"
	intro, e := ua.UDPResolveAddr(introducerAddr)
	if e != nil {
		t.Errorf("failed to UDPResolveAddr")
	}
	startPort1 := 20000
	for i := startPort1; i < startPort1+membersNumber-1; i++ {
		m := ua.CreateNode()
		gr, mailbox, e := m.JoinGroup(intro, "StoreGroup1", false, "[::1]",i, 100, 10, 10)
		if e != nil {
			t.Errorf("member failed to JoinGroup")
		}
		go func(a int) {
			for m := range mailbox {
				fmt.Println("m",a,"received", string(m.Body))
				if m.NeedReply {
					e = gr.Reply(m, append(m.Body,[]byte("Reply")...))
				}
			}
		}(i)
	}
	fmt.Println("Other members joined group")
	startPort2 := 30000
	for i := startPort2; i < startPort2+clientsNumber; i++ {
		m := ua.CreateNode()
		gr, mailbox, e := m.JoinGroup(intro, "StoreGroup1", true,"[::1]", i, 100, 10, 10)
		if e != nil {
			t.Errorf("client failed to JoinGroup")
		}
		go func(a int) {
			for m := range mailbox {
				fmt.Println("c",a,"received", string(m.Body))
				if m.NeedReply {
					e = gr.Reply(m, append(m.Body,[]byte("Reply")...))
				}
			}
		}(i)
	}
	fmt.Println("Clients joined group")
	tasks := []string{"a","b","c","d","e","f","g","h","i"}
	result := gr1.STasks2GroupLB(tasks)
	fmt.Println("gr1(port1231) STasks2GroupLB result:", result)
	if len(result) != len(tasks) {
		fmt.Println("len(result) != len(tasks)")
		t.Errorf("len(result) not correct")
	}else {
		fmt.Println("len(result) == len(tasks)")
	}
}