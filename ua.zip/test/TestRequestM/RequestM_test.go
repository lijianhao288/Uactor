package testRequestM
import (
	"Uactor/ua"
	"fmt"
	"net"
	"testing"
	"time"
)
func TestRequestM(t *testing.T) {
	toSendAddr := []*net.UDPAddr{}
	receiverPortNumber := 9999
	startPort := 20000
	fmt.Println("receiverPortNumber", receiverPortNumber, "startPort", startPort)
	for i := startPort; i < startPort+receiverPortNumber; i++ {
		c, mailbox, e := ua.Listen("[::1]", i, 100, 10)
		if e != nil {
			t.Errorf("receiver failed to Listen")
		}
		toSendAddr = append(toSendAddr, c.LocalAddr)
		go func() {
			for m := range mailbox {
				if m.NeedReply {
					e = c.Reply(m, []byte("reply"))
					if e != nil {
						t.Errorf("Failed to reply")
					}
					return
				}
			}
		}()
	}
	c, _, e := ua.Listen("[::1]", 1231, 100, 10)
	if e != nil {
		t.Errorf("sender failed to Listen")
	}
	result := c.RequestM(toSendAddr, "", []byte("Request"), 10*time.Second)
	if len(result) != receiverPortNumber {
		fmt.Println(len(result))
		t.Errorf("result len not correct")
	} else {
		fmt.Println("len(result) == receiverPortNumber")
	}
	c.Close()
}