package testMutex
import (
	"Uactor/ua"
	"fmt"
	"net"
	"sync"
	"testing"
	"time"
)
func TestMutex(t *testing.T) {
	var mu sync.Mutex
	result := []*net.UDPAddr{}
	c1, mailbox, e := ua.Listen("[::1]", 1231, 100, 10)
	if e != nil {
		t.Errorf("receiver failed to Listen")
	}
	defer c1.Close()
	go func() {
		for m := range mailbox {
			if m.NeedAck {
				e = c1.Ack(m)
				if e != nil {
					t.Errorf("receiver failed to ack")
				}
				mu.Lock()
				result = append(result, m.Sender)
				mu.Unlock()
			}
		}
	}()
	portNumber := 5000
	startPort := 20000
	fmt.Println("portNumber", portNumber, "startPort", startPort)
	remoteAddr := "[::1]:1231"
	remote, _ := ua.UDPResolveAddr(remoteAddr)
	for i := startPort; i < startPort+portNumber; i++ {
		c, _, e := ua.Listen("[::1]",i, 100, 10)
		if e != nil {
			t.Errorf("sender failed to Listen")
		}
		b1 := "aaa"
		c1.SendG(remote, "", []byte(b1), 2*time.Second, 3)
		c.Close()
	}
	time.Sleep(5 * time.Second)
	mu.Lock()
	if len(result) != portNumber {
		fmt.Println("len(result)", len(result))
		t.Errorf("len(result) not correct")
	} else {
		fmt.Println("len(result) == portNumber")
	}
	mu.Unlock()
}