package testSendGM
import (
	"Uactor/ua"
	"fmt"
	"io/ioutil"
	"net"
	"sync"
	"testing"
	"time"
)
func TestSendGMPass(t *testing.T) {
	var mu sync.RWMutex
	toSendAddr := []*net.UDPAddr{}
	receivedAddr := []*net.UDPAddr{}
	receiverPortNumber := 9999
	startPort := 20000
	fmt.Println("receiverPortNumber", receiverPortNumber, "startPort", startPort)
	for i := startPort; i < startPort+receiverPortNumber; i++ {
		c, mailbox, e := ua.Listen("[::1]",i, 100, 10)
		if e != nil {
			t.Errorf("receiver failed to Listen")
		}
		toSendAddr = append(toSendAddr, c.LocalAddr)
		go func() {
			for m := range mailbox {
				if m.NeedAck {
					c.Ack(m)
					mu.Lock()
					receivedAddr = append(receivedAddr, c.LocalAddr)
					mu.Unlock()
					return
				}
			}
		}()
	}
	c, _, e := ua.Listen("[::1]",1231, 100, 10)
	if e != nil {
		t.Errorf("sender failed to Listen")
	}
	c.SendGM(toSendAddr, "", []byte("Hi"), 10*time.Second, 3)
	c.Close()
	if len(toSendAddr) != receiverPortNumber {
		fmt.Println("len(toSendAddr)", len(toSendAddr))
		t.Errorf("toSendAddr number not correct")
	} else {
		fmt.Println("len(toSendAddr) == receiverPortNumber")
	}
	if len(receivedAddr) != receiverPortNumber {
		fmt.Println("len(receivedAddr)", len(receivedAddr))
		t.Errorf("receivedAddr number not correct")
	} else {
		fmt.Println("len(receivedAddr) == receiverPortNumber")
	}
}
func TestSendGMNotAck(t *testing.T) {
	toSendAddr := []*net.UDPAddr{}
	receiverPortNumber := 9999
	startPort := 30000
	fmt.Println("receiverPortNumber", receiverPortNumber, "startPort", startPort)
	for i := startPort; i < startPort+receiverPortNumber; i++ {
		c, _, e := ua.Listen("[::1]",i, 100, 10)
		if e != nil {
			t.Errorf("receiver failed to Listen")
		}
		defer c.Close()
		toSendAddr = append(toSendAddr, c.LocalAddr)
	}
	c, _, e := ua.Listen("[::1]",1232, 100, 10)
	if e != nil {
		t.Errorf("sender failed to Listen")
	}
	timeout := 2 * time.Second
	retryTimes := 2
	c.SendGM(toSendAddr, "", []byte("Hi"), timeout, retryTimes)
	if len(toSendAddr) != receiverPortNumber {
		fmt.Println("len(toSendAddr)", len(toSendAddr))
		t.Errorf("toSendAddr number not correct")
	} else {
		fmt.Println("len(toSendAddr) == receiverPortNumber")
	}
	c.Close()
	files, e := ioutil.ReadDir("./failedSendG/")
	if e != nil {
		fmt.Println(e)
		t.Errorf("failed to ReadDir")
	}
	if len(files) != receiverPortNumber {
		fmt.Println("len(files)", len(files))
		t.Errorf("len(files) not correct")
	} else {
		fmt.Println("len(files) == receiverPortNumber")
	}
	ua.DeleteMsgFolder()
}