package testLocalScale
import (
	"Uactor/ua"
	"fmt"
	"math/rand"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)
func TestLocalScale(t *testing.T) {
	var maxGo int
	var maxGomu sync.Mutex
	go func() {
		for {
			n := runtime.NumGoroutine()
			if n > maxGo {
				maxGomu.Lock()
				maxGo = n
				maxGomu.Unlock()
			}
			time.Sleep(200 * time.Millisecond)
		}
	}()
	membersNumber := 900
	clientsNumber := 900
	subTag := "Cluster1"
	fmt.Println("membersNumber", membersNumber)
	fmt.Println("clientsNumber", clientsNumber)
	var subMsgCounter uint64
	var ackCounter uint64
	var replyCounter uint64
	m1 := ua.CreateNode()
	gr1, mailbox1, e := m1.CreateGroup("StoreGroup1","[::1]", 1231, 100, 10, 10)
	if e != nil {
		t.Errorf("failed to CreateGroup")
	}
	go func() {
		for m := range mailbox1 {
			if m.NeedAck {
				gr1.Ack(m)
				atomic.AddUint64(&ackCounter, uint64(1))
			}
			if m.NeedReply {
				e = gr1.Reply(m, []byte("2"))
				atomic.AddUint64(&replyCounter, uint64(1))
			}
		}
	}()
	fmt.Println("Member created group, GroupRelation variable: gr1")
	introducerAddr := "[::1]:1231"
	intro, e := ua.UDPResolveAddr(introducerAddr)
	if e != nil {
		t.Errorf("failed to UDPResolveAddr")
	}
	src := rand.NewSource(time.Now().UnixNano())
	rd := rand.New(src)
	startPort1 := 20000
	mebmerPickedPort := rd.Intn(membersNumber-1) + startPort1
	fmt.Println("mebmerPickedPort", mebmerPickedPort, ", GroupRelation variable: pickedGrM")
	var pickedGrM *ua.GroupRelation
	for i := startPort1; i < startPort1+membersNumber-1; i++ {
		m := ua.CreateNode()
		gr, mailbox, e := m.JoinGroup(intro, "StoreGroup1", false, "[::1]", i, 100, 10, 10)
		if e != nil {
			t.Errorf("member failed to JoinGroup")
		}
		if i == mebmerPickedPort {
			pickedGrM = gr
		}
		go func() {
			for m := range mailbox {
				if m.NeedAck {
					gr.Ack(m)
					atomic.AddUint64(&ackCounter, uint64(1))
				}
				if m.NeedReply {
					e = gr.Reply(m, []byte("2"))
					atomic.AddUint64(&replyCounter, uint64(1))
				}
			}
		}()
		if i%2 == 0 {
			subCh, e := gr.GroupSub(subTag)
			if e != nil {
				t.Errorf("failed to GroupSub")
			}
			go func() {
				for m := range subCh {
					if m.NeedAck {
						gr.Ack(m)
						atomic.AddUint64(&subMsgCounter, uint64(1))
					}
				}
			}()
		}
	}
	fmt.Println("Other members joined group")
	startPort2 := 30000
	clientPickedPort := rd.Intn(clientsNumber) + startPort2
	var pickedGrC *ua.GroupRelation
	fmt.Println("clientPickedPort", clientPickedPort, ", GroupRelation variable: pickedGrC")
	for i := startPort2; i < startPort2+clientsNumber; i++ {
		m := ua.CreateNode()
		gr, mailbox, e := m.JoinGroup(intro, "StoreGroup1", true, "[::1]", i, 100, 10, 10)
		if e != nil {
			t.Errorf("client failed to JoinGroup")
		}
		if i == clientPickedPort {
			pickedGrC = gr
		}
		go func() {
			for m := range mailbox {
				if m.NeedAck {
					gr.Ack(m)
					atomic.AddUint64(&ackCounter, uint64(1))
				}
				if m.NeedReply {
					e = gr.Reply(m, []byte("2"))
					atomic.AddUint64(&replyCounter, uint64(1))
				}
			}
		}()
	}
	fmt.Println("Clients joined group")
	if gr1.GetMemberLen() != membersNumber-1 {
		fmt.Println("gr1.GetMemberLen()", gr1.GetMemberLen())
		t.Errorf("gr1.GetMemberLen() not correct")
	} else {
		fmt.Println("gr1.GetMemberLen() == membersNumber-1")
	}
	if gr1.GetClientLen() != clientsNumber {
		fmt.Println("gr1.GetClientLen()", gr1.GetClientLen())
		t.Errorf("gr1.GetClientLen() not correct")
	} else {
		fmt.Println("gr1.GetClientLen() == clientsNumber")
	}
	if pickedGrM.GetMemberLen() != membersNumber-1 {
		fmt.Println("pickedGrM.GetMemberLen()", pickedGrM.GetMemberLen())
		t.Errorf("pickedGrM.GetMemberLen() not correct")
	} else {
		fmt.Println("pickedGrM.GetMemberLen() == membersNumber-1")
	}
	if pickedGrM.GetClientLen() != clientsNumber {
		fmt.Println("pickedGrM.GetClientLen()", pickedGrM.GetClientLen())
		t.Errorf("pickedGrM.GetClientLen() not correct")
	} else {
		fmt.Println("pickedGrM.GetClientLen() == clientsNumber")
	}
	if pickedGrC.GetMemberLen() != membersNumber {
		fmt.Println("pickedGrC.GetMemberLen()", pickedGrC.GetMemberLen())
		t.Errorf("pickedGrC.GetMemberLen() not correct")
	} else {
		fmt.Println("pickedGrC.GetMemberLen() == membersNumber")
	}
	if pickedGrC.GetClientLen() != 0 {
		fmt.Println("pickedGrC.GetClientLen()", pickedGrC.GetClientLen())
		t.Errorf("pickedGrC.GetClientLen() not correct")
	} else {
		fmt.Println("pickedGrC.GetClientLen() == 0")
	}
	gr1.GroupSendBC([]byte("1"))
	gr1.GroupSendPub("Cluster1", []byte("1"))
	groupRequestResult1 := gr1.GroupRequestBC([]byte("1"))
	fmt.Println("gr1 GroupSendBC, GroupSendPub and GroupRequestBC")
	pickedGrM.GroupSendBC([]byte("1"))
	pickedGrM.GroupSendPub("Cluster1", []byte("1"))
	groupRequestResult2 := pickedGrM.GroupRequestBC([]byte("1"))
	fmt.Println("pickedGrM GroupSendBC, GroupSendPub and GroupRequestBC")
	pickedGrC.GroupSendBC([]byte("1"))
	pickedGrC.GroupSendPub("Cluster1", []byte("1"))
	groupRequestResult3 := pickedGrC.GroupRequestBC([]byte("1"))
	fmt.Println("pickedGrC GroupSendBC, GroupSendPub and GroupRequestBC")
	time.Sleep(10 * time.Second)
	if len(groupRequestResult1) != membersNumber-1 {
		fmt.Println("len(groupRequestResult1)", len(groupRequestResult1))
		t.Errorf("len(groupRequestResult1) not correct")
	} else {
		fmt.Println("len(groupRequestResult1) == membersNumber-1")
	}
	if len(groupRequestResult2) != membersNumber-1 {
		fmt.Println("len(groupRequestResult2)", len(groupRequestResult2))
		t.Errorf("len(groupRequestResult2) not correct")
	} else {
		fmt.Println("len(groupRequestResult2) == membersNumber-1")
	}
	if len(groupRequestResult3) != membersNumber {
		fmt.Println("len(groupRequestResult3)", len(groupRequestResult3))
		t.Errorf("len(groupRequestResult3) not correct")
	} else {
		fmt.Println("len(groupRequestResult3) == membersNumber")
	}
	if (atomic.LoadUint64(&subMsgCounter) != uint64(450*3)) && (atomic.LoadUint64(&subMsgCounter) != uint64(450*3-1)) {
		fmt.Println("atomic.LoadUint64(&subMsgCounter)", atomic.LoadUint64(&subMsgCounter))
		t.Errorf("atomic.LoadUint64(&subMsgCounter) not correct")
	} else {
		fmt.Println("atomic.LoadUint64(&subMsgCounter) == (450*3) or (450*3-1)")
	}
	if atomic.LoadUint64(&ackCounter) != uint64(900*3-2) {
		fmt.Println("atomic.LoadUint64(&ackCounter)", atomic.LoadUint64(&ackCounter))
		t.Errorf("atomic.LoadUint64(&ackCounter) not correct")
	} else {
		fmt.Println("atomic.LoadUint64(&ackCounter) == 900*3 - 2")
	}
	if atomic.LoadUint64(&replyCounter) != uint64(900*3-2) {
		fmt.Println("atomic.LoadUint64(&replyCounter)", atomic.LoadUint64(&replyCounter))
		t.Errorf("atomic.LoadUint64(&replyCounter) not correct")
	} else {
		fmt.Println("atomic.LoadUint64(&replyCounter) == 900*3 - 2")
	}
	maxGomu.Lock()
	fmt.Println("Max goroutine number: ", maxGo)
	maxGomu.Unlock()
}