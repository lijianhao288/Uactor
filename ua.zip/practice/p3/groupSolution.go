package main
import (
	"Uactor/ua"
	"fmt"
)
func main() {
	m1 := ua.CreateNode()
	gr1, mailbox, _ := m1.CreateGroup("StoreGroup1", "[::1]", 1231, 100, 10, 10)
	go func() {
		for m := range mailbox {
			fmt.Println("M1 mailbox received", string(m.Body),
			"from", m.Sender)
			if m.NeedAck {
				gr1.Ack(m)
			}
		}
	}()
	m1log, _ := gr1.GroupSub("log")
	go func() {
		for m := range m1log {
			fmt.Println("M1 log channel received", string(m.Body), 
			"from", m.Sender)
			if m.NeedAck {
				gr1.Ack(m)
			}
		}
	}()
	introducerAddr := "[::1]:1231"
	intro, _ := ua.UDPResolveAddr(introducerAddr)
	m2 := ua.CreateNode()
	gr2, mailbox2, _ := m2.JoinGroup(intro, "StoreGroup1", 
	false, "[::1]", 1232, 100, 10, 10)
	go func() {
		for m := range mailbox2 {
			fmt.Println("M2 mailbox received", string(m.Body), 
			"from", m.Sender)
			if m.NeedAck {
				gr2.Ack(m)
			}
		}
	}()
	m2log, _ := gr2.GroupSub("log")
	go func() {
		for m := range m2log {
			fmt.Println("M2 log channel received", string(m.Body), 
			"from", m.Sender)
			if m.NeedAck {
				gr2.Ack(m)
			}
		}
	}()
	m3 := ua.CreateNode()
	gr3, mailbox3, _ := m3.JoinGroup(intro, "StoreGroup1", 
	false, "[::1]", 1233, 100, 10, 10)
	go func() {
		for m := range mailbox3 {
			fmt.Println("M3 mailbox received", string(m.Body), 
			"from", m.Sender)
			if m.NeedAck {
				gr3.Ack(m)
			}
		}
	}()
	introducerAddr2 := "[::1]:1232"
	intro2, _ := ua.UDPResolveAddr(introducerAddr2)
	c1 := ua.CreateNode()
	c1g1, _, _ := c1.JoinGroup(intro2, "StoreGroup1", 
	true, "[::1]", 1331, 100, 10, 10)
	c2 := ua.CreateNode()
	_, _, _ = c2.JoinGroup(intro2, "StoreGroup1", 
	true, "[::1]", 1332, 100, 10, 10)
	c1g1.GroupSendLB([]byte("c1 lb1"))
	c1g1.GroupSendLB([]byte("c1 lb2"))
	c1g1.GroupSendLB([]byte("c1 lb3"))
	c1g1.GroupSendLB([]byte("c1 lb4"))
	c1g1.GroupSendBC([]byte("c1 bc1"))
	c1g1.GroupSendPub("log", []byte("c1 pub1"))
	forever := make(chan bool)
	<-forever
}