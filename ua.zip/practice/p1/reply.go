package main
import (
	"Uactor/ua"
	"fmt"
)
func main() {
	c1, mailbox, e := ua.Listen("[::1]", 1232, 100, 10)
	if e != nil {
		fmt.Println(e)
	}
	go func() {
		for m := range mailbox {
			if m.NeedReply {
				fmt.Println("received request", m)
				requestString := string(m.Body)
				reply := requestString+"reply"
				_ = c1.Reply(m, []byte(reply))
				fmt.Println("Sent reply", reply)
			} 
		}
	}()
	forever := make(chan bool)
	<-forever
}