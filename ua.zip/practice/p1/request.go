package main
import (
	"Uactor/ua"
	"fmt"
	"time"
)
func main() {
	c1, _, e := ua.Listen("[::1]", 1231, 100, 10)
	if e != nil {
		fmt.Println(e)
	}
	remote, _ := ua.UDPResolveAddr("[::1]:1232")
	reply, e := c1.Request(remote, "", []byte("aaa"), 5*time.Second)
	if e != nil {
		fmt.Println(e)
	}
	fmt.Println("received reply", string(reply.Body))
}
